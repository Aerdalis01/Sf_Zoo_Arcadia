export interface Image {
  id: number;
  nom: string;
  image_path: string;
  image_sub_directory: string;
}