export interface Contact {
  id: number,
  email: string,
  titre: string,
  message: string,
}