export interface Avis {
  id: number,
  nom: string,
  avis: string,
  note: number,
  
}