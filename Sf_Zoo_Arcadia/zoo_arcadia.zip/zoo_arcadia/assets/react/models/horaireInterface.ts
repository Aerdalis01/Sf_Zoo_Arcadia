export interface Horaire {
  id?: number;
  horaireTexte: string;
}