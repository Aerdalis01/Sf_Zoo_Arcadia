// if (!response.ok) {
// if (response.status === 401) {
//   setError("Vous n'avez pas l'autorisation requise pour cette action.");
//   return;
// }

//   {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}
//   {successMessage && <div style={{ color: 'green', marginBottom: '10px' }}>{successMessage}</div>}
