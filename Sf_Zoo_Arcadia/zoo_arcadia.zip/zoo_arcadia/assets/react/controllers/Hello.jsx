import React from 'react';

export default function (props) {
    return <div>Hello {props.fullName}</div>;
}
