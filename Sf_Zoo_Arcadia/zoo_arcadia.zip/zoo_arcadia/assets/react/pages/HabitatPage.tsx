import React from 'react';
import {HabitatList} from '../controllers/components/form/HabitatList';

export const HabitatPage = () => {
    return (
        <div>
            <HabitatList />
        </div>
    );
};

