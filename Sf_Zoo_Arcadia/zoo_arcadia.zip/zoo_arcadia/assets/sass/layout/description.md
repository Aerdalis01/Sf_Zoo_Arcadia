# layout

On met ici tous les fichiers de styles pour les éléments plus "généralistes" qui gèrent la structure du site.

Exemples :

- le footer
- le header
- une disposition en grille
- une barre latérale
- un flux pour aligner le contenu
- ...

